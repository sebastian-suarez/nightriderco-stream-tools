NIGHTRIDERCO Panel Frames 1.1.0
OBS Studio32.2.2 / Qt6.11.1 / arm64
